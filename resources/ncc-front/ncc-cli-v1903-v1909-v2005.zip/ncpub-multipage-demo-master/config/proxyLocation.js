module.exports = function proxyLocation(reqUrl, configJSON, rootPath){
    let ReqEntry = configJSON.buildEntryPath.find((item)=>{
        let itemModulePath = /(?:\.\/src\/)*([^\.]*)\./.exec(item);
        let itemPath = null
        if(itemModulePath && itemModulePath[1]){
            itemPath = itemModulePath[1].split('/'); //存放四级目录，如lowcode/light-front/*/*/index
        }
        //json文件走本地判断
        if(reqUrl.startsWith('/' + rootPath + '/resources/') && reqUrl.endsWith('json') && configJSON.proxyJson){
            let domainName = reqUrl.split('/')[3];
            if(itemPath && itemPath[0] == domainName){
                return true;
            }
            return false;
        //js和html文件走本地判断
        }else{
            // 过滤出 reqUrl 的四级目录
            let reqModulePath = new RegExp('(?:\/' + rootPath  + '\/resources\/)*([^\.]*)\.').exec(reqUrl);
            let reqPath = null;
            if(reqModulePath && reqModulePath[1]){
                reqPath = reqModulePath[1].split('/'); //存放四级目录，如lowcode/light-front/runtime/main/index
            }
            if(reqPath && itemPath && reqPath.length === itemPath.length){
                //判断itemPath不是*号的部分是否与reqPath全部相等，是则使用本地资源，否则使用线上资源
                let isEqual = true;
                for(let index=0; index<itemPath.length; index++){
                    if(itemPath[index]!='*' && itemPath[index] != reqPath[index]){
                        isEqual= false;
                        break;
                    }
                }
                return isEqual;
            }
            return false;
        }
    })
    if(ReqEntry){
        return true;
    }
    return false
}
