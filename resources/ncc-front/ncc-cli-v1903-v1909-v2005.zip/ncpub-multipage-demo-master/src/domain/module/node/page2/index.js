/*
 * @Author: liyxt
 * @Date: 2020-01-04 14:19:27
 * @LastEditors: liyxt
 * @LastEditTime: 2020-04-23 16:52:54
 * @Description: file content
 */
import React from 'react';

export default class Demo extends Page {
	constructor(props) {
		super(props);
		this.state = {};
	}

	render() {
		return this.layout();
	}
}
