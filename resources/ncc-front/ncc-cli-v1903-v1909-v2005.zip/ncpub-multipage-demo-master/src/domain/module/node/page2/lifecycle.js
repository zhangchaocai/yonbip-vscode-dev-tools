/*
 * @Author: liyxt
 * @Date: 2020-01-04 14:19:58
 * @LastEditors  : liyxt
 * @LastEditTime : 2020-01-06 14:17:40
 * @Description: file content
 */
export function componentDidMount() {}

export function componentWillUnmount() {}

registerLifecycle({});
