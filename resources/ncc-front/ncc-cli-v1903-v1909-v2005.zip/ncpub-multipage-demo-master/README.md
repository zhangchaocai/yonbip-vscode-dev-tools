## 分支说明：

### NCC1903、NCC1909、 NCC2005 脚手架分支为: master


### 其余版本 脚手架分支为：  develop-ncc3.0


## 使用说明：

脚手架使用说明文档 [点击此处查看](http://git.yonyou.com/nc-pub/Public_Document/blob/master/%E5%89%8D%E7%AB%AF%E6%A1%86%E6%9E%B6/PC%E7%AB%AF%E6%A1%86%E6%9E%B6/%E5%BF%AB%E9%80%9F%E5%BC%80%E5%8F%91%E6%8C%87%E5%AF%BC/1.%E5%BC%80%E5%8F%91%E7%8E%AF%E5%A2%83%E6%90%AD%E5%BB%BA/%E6%AD%A5%E9%AA%A4%E7%BB%86%E5%88%99/2.%E5%89%8D%E7%AB%AF%E5%B7%A5%E7%A8%8B%E9%A1%B9%E7%9B%AE%E6%90%AD%E5%BB%BA.md)

## 注意
npm版本太高可能导致npm i失败，需要降至6版本
```
npm i npm@6 -g
```

node版本过高，npm i 会报错，建议使用16.14版本的node

npm i 环境报错问题的解决方案

1. 删除node_module和package-lock.json文件
2. 下载安装 16.14 版本的node
3. 清除npm缓存 npm cache clean --force
4. 安装cnpm镜像 npm install -g cnpm --registry=https://registry.npm.taobao.org
5. cnpm install安装依赖
6. npm run dev 启动 npm run patch打包
