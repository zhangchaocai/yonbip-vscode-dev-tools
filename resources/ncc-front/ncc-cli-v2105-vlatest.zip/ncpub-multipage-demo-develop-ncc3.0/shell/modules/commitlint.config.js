// commitlint配置样板
module.exports = { extends: ['@commitlint/config-conventional'] };
