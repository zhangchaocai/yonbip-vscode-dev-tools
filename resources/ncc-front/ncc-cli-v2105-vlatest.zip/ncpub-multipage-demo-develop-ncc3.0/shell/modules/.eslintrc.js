const ESLintConfig = require('../../config/ESLintConfig');

module.exports = ESLintConfig;
