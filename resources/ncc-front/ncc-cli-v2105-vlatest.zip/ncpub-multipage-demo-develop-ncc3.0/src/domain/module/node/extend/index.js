export default function(){

    return{
        init: function(){
        // 导出业务扩展代码
        console.log("执行低代码业务扩展代码")
        }
    }
    
}