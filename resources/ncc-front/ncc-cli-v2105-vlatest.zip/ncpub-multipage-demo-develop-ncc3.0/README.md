## 脚手架代码加测及提交检测工具

[请参考](http://git.yonyou.com/nc-pub/Public_Document/blob/master/%E5%BC%80%E5%8F%91%E8%A7%84%E8%8C%83/%E8%84%9A%E6%89%8B%E6%9E%B6%E4%BB%A3%E7%A0%81%E8%A7%84%E8%8C%83%E5%8F%8A%E6%8F%90%E4%BA%A4%E8%A7%84%E8%8C%83%E6%A0%A1%E9%AA%8C%E5%B7%A5%E5%85%B7.md)
