/*
 * @Author: liyxt
 * @Date: 2018-09-17 11:10:21
 * @LastEditors: liyxt
 * @LastEditTime: 2020-04-08 09:34:15
 * @Description: file content
 */
const configJSON = require('../config.json');
const buildEntry = require('./buildEntry');
const { spawn } = require('child_process');

// buildPath是npm参数
let buildParam,
	paramMap = {};
if (process.env.npm_config_argv) {
	[, , ...buildParam] = JSON.parse(process.env.npm_config_argv).original;
} else {
	[, , , ...buildParam] = process.argv;
}

buildParam.forEach(param => {
	let [key, value] = param.split('=');
	paramMap[key] ? paramMap[key].push(value) : (paramMap[key] = [value]);
});
let buildEntryPath = (paramMap['--env.buildPath'] || []).filter(e => e),
	buildOutputPath = paramMap['--env.buildOutputPath'] || [],
	patchList = paramMap['--env.patchList'] ? paramMap['--env.patchList'][0] : '',
	srcDir = paramMap['--env.srcDir'] ? paramMap['--env.srcDir'][0] : configJSON.srcDir || '',
	log = paramMap['--env.log'] ? paramMap['--env.log'][0] : 'false';

if (!buildEntryPath.length) {
	buildEntryPath = configJSON.buildEntryPath || './src/*/*/*/*/index.js';
}
let buildWithoutHTML = configJSON.buildWithoutHTML;
buildWithoutHTML && typeof buildWithoutHTML === 'string' && (buildWithoutHTML = [buildWithoutHTML]);

// mode是nodeJs参数
let [, , mode, client] = process.argv;

let { entries: hashEntries } = buildEntry({ buildPath: buildEntryPath, buildWithoutHTML, hash: true, client, mode });
let { entries } = buildEntry({ buildPath: buildEntryPath, buildWithoutHTML, hash: false, client, mode });

// 加载打包二开相关文件
let extendBuildEntryPath = configJSON.extendBuildEntryPath || [];
let { entries: extendEntries } = buildEntry({
	buildPath: extendBuildEntryPath,
	buildWithoutHTML,
	hash: false,
	client,
	fse: true,
	mode,
});

if (Object.keys(hashEntries).length) {
	runSpawn(buildEntryPath, mode, true, false);
}
if (Object.keys(entries).length) {
	runSpawn(buildEntryPath, mode, false, false);
}

if (Object.keys(extendEntries).length) {
	runSpawn(extendBuildEntryPath, mode, false, true);
}


function runSpawn(buildEntryPath, mode, hash, fse) {
	let extParams = [];
	srcDir && extParams.push(`--env.srcDir=${srcDir}`);
	patchList && extParams.push(`--env.patchList=${patchList}`);

	const ls = spawn('node', [
		'--max_old_space_size=4096',
		'node_modules/webpack/bin/webpack.js',
		'--progress',
		'--colors',
		'--config',
		'./config/webpack.prod.config.js',
		...buildEntryPath.map(e => '--env.buildPath=' + e),
		`--env.mode=${mode}`,
		`--env.hash=${hash}`,
		`--env.client=${client}`,
		`--env.fse=${fse}`,
		`--env.outputPath=${buildOutputPath.join('/')}`,
		...extParams,
	]);

	let process = 0;

	ls.stdout.on('data', data => {
		print(data);
	});

	ls.stderr.on('data', data => {
		print(data);
	});

	function print(data) {
		if (!data) {
			return;
		}

		data = data.toString();

		if (data.includes('ERROR')) {
			console.log(data);
			throw new Error(data);
		} else {
			if (log === 'true') {
				console.log(data);
			} else {
				if (data.match(/\[webpack\.Progress\]\s(.*)%/)) {
					let next = Number(data.match(/\[webpack\.Progress\]\s(.*)%/)[1]);
					if (next > process) {
						process = next;
						console.log('[webpack.progress]' , process, '%');
					}
				} else {
					console.log(data);
				}
			}
		}
	}
}
