module.exports = function fileRules({ cssSandbox = false, chunk='' } = {}) {

    const postcssLoader = cssSandbox ? {
        loader: 'postcss-loader',
        options: {
            postcssOptions: {
                plugins: [
                    require('postcss-prefix-selector')({
                      prefix: '.' + chunk.split('/').join('_') , // 需要动态设置
                    }),
                  ]
            },
        }
    }: 'postcss-loader';

    const rules = [
        {
            test: /\.js[x]?$/,
            exclude: /node_modules/,
            use: [
                {
                    loader: 'babel-loader'
                }
            ]
        },
        {
            test: /\.css$/,
            // use: ExtractTextPlugin.extract({
            use: [
                'style-loader', 
                'css-loader', 
                postcssLoader
            ]
            // 	fallback: 'style-loader'
            // })
        },
        {
            test: /\.less$/,
            // use: ExtractTextPlugin.extract({
            use: [
                'style-loader', 
                'css-loader', 
                postcssLoader,
                'less-loader'
            ]
            // fallback: 'style-loader'
            // })
        },
        {
            test: /\.(png|jpg|jpeg|gif|eot|ttf|woff|woff2|svg|svgz|ico|xlsx)(\?.+)?$/,
            exclude: /favicon\.png$/,
            use: [
                {
                    loader: 'url-loader'
                }
            ]
        }
    ];

	return rules;
};