/*
 * @Author: xuyangt
 * @Description:
 * @Date: 2024-01-09 13:47:34
 * @LastEditTime: 2024-04-19 17:08:48
 */
const fs = require('fs');
const XLSX = require('xlsx');
const path = require('path');

function readColumnFromExcel(excelPath, sheetName, columnName) {
    // 读取Excel文件
    const workbook = XLSX.readFile(excelPath);
    // 获取指定的sheet
    const worksheet = workbook.Sheets[sheetName];
    // 将sheet转换为JSON对象数组
    const jsonData = XLSX.utils.sheet_to_json(worksheet, {header:1});
    // 获取列名在第一行的索引
    const columnIndex = jsonData[0].indexOf(columnName);
    // 读取指定列的数据
    const columnData = jsonData.map(row => row[columnIndex]);
    // 移除列名
    columnData.shift();
    return columnData;
}
//在指定目录下创建文件夹
function createDir(dirPath) {
		if (!fs.existsSync(dirPath)) {
				fs.mkdirSync(dirPath);
		}
}
//在指定目录下创建JSON文件
function createJsonFile(dirPath,fileName,data){
		fs.writeFileSync(path.join(dirPath,fileName),JSON.stringify(data,null,2));
}
//往指定目录下的JSON文件中添加数据
function addJsonFile(dirPath,fileName,data){
		let filePath = path.join(dirPath,fileName);
		let fileData = fs.readFileSync(filePath);
		let jsonData = JSON.parse(fileData);
		jsonData = Object.assign(jsonData,data);
		fs.writeFileSync(filePath,JSON.stringify(jsonData,null,2));
}
function genModelConfig(excelPath) {
    const sheetName = 'SM_APPPAGE';
		const columnName = 'PAGEURL';
		const columnData = readColumnFromExcel(excelPath, sheetName, columnName);
		//过滤columnData中不以'/nccloud/resources‘开头或者不以'../../../../'开头的数据
		const filterData = columnData.filter(item => {
			return item.startsWith('/nccloud/resources') || item.startsWith('../../../../');
		});
		const modelConfig = {};
		filterData.forEach(item=>{
			let model = '',entryPath = '',target="";
			if(item.indexOf('/nccloud/resources')>-1){
				target='/nccloud/resources/';
			}else if(item.indexOf('../../../../')>-1){
				target='../../../../';
			}
			if(target){
				try{
					model = item.split(target)[1]?.split('/')[0];
					if(item.includes('.html')){
						entryPath ='./src/'+ item.split(target)[1]?.split(".html")[0]+'.js';
					}else if(item.includes('.js')){
						entryPath ='./src/'+ item.split(target)[1];
					}
					
					if(model){
						if( modelConfig[model]){
							if(modelConfig[model].buildEntryPath.indexOf(entryPath)===-1){
								modelConfig[model].buildEntryPath.push(entryPath);
							}
						}else{
							modelConfig[model] = {
								buildEntryPath:[entryPath]
							}
						}
					}
				}catch(e){
					console.error("item",item);
				}
			}
		});
		//判断dist文件夹是否存在，不存在则创建
		createDir(path.resolve(process.cwd(), './dist'));

		//判断dist/modelConfig文件夹是否存在，不存在则创建
		createDir(path.resolve(process.cwd(), './dist/modelConfig'));
		//遍历modelConfig对象，往dist/modelConfig文件夹下的json文件中添加数据
		for(let key in modelConfig){
			let data = modelConfig[key];
			createDir(path.resolve(process.cwd(), `./dist/modelConfig/${key}`));
			if(fs.existsSync(path.resolve(process.cwd(), `./dist/modelConfig/${key}/config.json`))){
				addJsonFile(path.resolve(process.cwd(), `./dist/modelConfig/${key}`),`config.json`,data);
			}else{
				createJsonFile(path.resolve(process.cwd(), `./dist/modelConfig/${key}`),`config.json`,data);
			}
		}
}


genModelConfig(process.argv[2]);
